/**
 */
package iCal.impl;

import iCal.AlarmType;
import iCal.ICalPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Alarm Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class AlarmTypeImpl extends MinimalEObjectImpl.Container implements AlarmType {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AlarmTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ICalPackage.Literals.ALARM_TYPE;
	}

} //AlarmTypeImpl
