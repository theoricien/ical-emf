/**
 */
package iCal;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>AMonth T</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iCal.ICalPackage#getAMonthT()
 * @model abstract="true"
 * @generated
 */
public interface AMonthT extends EObject {
} // AMonthT
