/**
 */
package iCal.impl;

import iCal.AMonthT;
import iCal.ICalPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>AMonth T</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class AMonthTImpl extends MinimalEObjectImpl.Container implements AMonthT {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AMonthTImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ICalPackage.Literals.AMONTH_T;
	}

} //AMonthTImpl
