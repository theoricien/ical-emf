/**
 */
package iCal.impl;

import iCal.ICalPackage;
import iCal.JournalC;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Journal C</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class JournalCImpl extends ComponentActionImpl implements JournalC {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JournalCImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ICalPackage.Literals.JOURNAL_C;
	}

} //JournalCImpl
