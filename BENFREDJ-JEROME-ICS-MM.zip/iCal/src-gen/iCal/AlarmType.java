/**
 */
package iCal;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Alarm Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iCal.ICalPackage#getAlarmType()
 * @model abstract="true"
 * @generated
 */
public interface AlarmType extends EObject {
} // AlarmType
