/**
 */
package iCal;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Journal C</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iCal.ICalPackage#getJournalC()
 * @model
 * @generated
 */
public interface JournalC extends ComponentAction {
} // JournalC
